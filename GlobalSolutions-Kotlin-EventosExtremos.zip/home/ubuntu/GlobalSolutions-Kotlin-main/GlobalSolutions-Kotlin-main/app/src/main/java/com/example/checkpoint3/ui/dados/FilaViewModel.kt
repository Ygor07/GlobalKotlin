package com.example.checkpoint3.ui.dados

import androidx.lifecycle.ViewModel

class FilaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}