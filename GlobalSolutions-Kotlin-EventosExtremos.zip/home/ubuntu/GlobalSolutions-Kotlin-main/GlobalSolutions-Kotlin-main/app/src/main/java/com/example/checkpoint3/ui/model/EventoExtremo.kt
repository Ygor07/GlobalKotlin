package com.example.checkpoint3.ui.model

data class EventoExtremo(
    val nomeLocal: String,
    val tipoEvento: String,
    val grauImpacto: String,
    val dataEvento: String,
    val pessoasAfetadas: Int
)

