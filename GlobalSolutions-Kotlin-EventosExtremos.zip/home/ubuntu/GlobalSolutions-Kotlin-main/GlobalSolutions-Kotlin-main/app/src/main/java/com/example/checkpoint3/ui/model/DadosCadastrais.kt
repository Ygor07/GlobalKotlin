package com.example.checkpoint3.ui.model

data class DadosCadastrais(
    var nome: String = "",
    var sobrenome: String = "",
    var email: String = "",
    var celular: String = "",
    var rg: String = "",
    var dataNascimento: String = ""
)
